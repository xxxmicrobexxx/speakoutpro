<?php

function dk_speakout_import_page() {
	include_once( dirname( __FILE__ ) . '/import.view.php' );
}

?>
