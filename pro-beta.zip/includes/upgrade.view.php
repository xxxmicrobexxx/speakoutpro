<h1>Upgrade to SpeakOut! Pro</h1>
<div>
    <p>To support further development of the SpeakOut! plugin, there is now a Pro version for a one-off lifetime price.</p>  <p>The free version will still have a lot of functionality, I want it to work for groups that don't have any funds.  But for the full feature list, you will need to upgrade.</p>
</div>
<div> <p>For more information on the features available <a href="https://speakoutpetitions.com/faqconc/why-a-premium-version/" target="_blank">click here</a>.</p></div>
<div><p>To upgrade, <a href="https://speakoutpetitions.com/product/speakout-wordpress-petition-plugin-upgrade/" target="_blank">click here.</a></p></div>
<div><p>If you have a license key, enter it in the <em>license</em> tab <a href="<?php site_url(); ?>/wp-admin/admin.php?page=dk_speakout_settings">here</a></p></div>