<?php

namespace MailchimpMarketing;

use MailchimpMarketing\Configuration;

class ApiClient extends Configuration {}
